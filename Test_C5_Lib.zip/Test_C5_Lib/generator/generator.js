Blockly.Arduino['test_c5_hello'] = function (block) {
    return 'Serial.println("Hello from C5 Custom Lib!");\n';
};
